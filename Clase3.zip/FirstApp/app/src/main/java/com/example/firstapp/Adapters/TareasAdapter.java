package com.example.firstapp.Adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.firstapp.Models.Tarea;
import com.example.firstapp.R;

import java.util.List;

public class TareasAdapter extends BaseAdapter {

    private List<Tarea> tareas;

    public TareasAdapter(List<Tarea> tareas){

        super();
        this.tareas = tareas;

    }



    @Override
    public int getCount() {
        return this.tareas.size();
    }

    @Override
    public Tarea getItem(int position) {
        return this.tareas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        View view;


        if(convertView == null){
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tareas,parent,false);

        }else{
            view = convertView;
        }

        TextView tvTarea = view.findViewById(R.id.tv_tarea_nombre);

        TextView tvUrgencia = view.findViewById(R.id.tv_tarea_urgencia);

        ImageView ivVencida = view.findViewById(R.id.iv_tarea_vencida);

        Tarea tarea = getItem(position);

        tvTarea.setText(this.getItem(position).getTitulo());

        tvUrgencia.setText(this.getItem(position).getUrgencia());

        if(tarea.isVencida()){

            ivVencida.setVisibility(View.VISIBLE);

        }else{

            ivVencida.setVisibility(View.GONE);

        }



        return view;
    }



}
