package com.example.firstapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.firstapp.Models.Tarea;

public class CrearTarea extends AppCompatActivity implements View.OnClickListener {

    private EditText etNombretarea,etUrgenciaTarea;
    private Button btnCrearTarea;

    private Tarea tarea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_tarea);

        etNombretarea = findViewById(R.id.et_tarea_crear);
        etUrgenciaTarea = findViewById(R.id.et_urgencia_crear);
        btnCrearTarea = findViewById(R.id.btn_crear_tarea);



        btnCrearTarea.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        if(v == btnCrearTarea){

            this.registerTask();

        }

    }

    public void registerTask() {

        Intent intent = new Intent(CrearTarea.this, TareasActivity.class);

        intent.putExtra("nombre_tarea",etUrgenciaTarea.getText().toString());
        intent.putExtra("urgencia_tarea",etUrgenciaTarea.getText().toString());



        startActivity(intent);
        finish();
    }
}
